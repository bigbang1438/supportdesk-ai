import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: { host: '127.0.0.1', proxy: { '/api': { target: 'http://127.0.0.1:8080', changeOrigin: true, headers: { Origin: 'http://127.0.0.1:8080' } } } },
  build: { outDir: 'dist', sourcemap: false }
})
