package com.supportdesk;

import org.springframework.http.HttpStatus;

public class ApiException extends RuntimeException {
    private final HttpStatus status;
    private final String code;
    public ApiException(HttpStatus status, String code, String message) { super(message); this.status=status; this.code=code; }
    public ApiException(int status, String code, String message) { this(HttpStatus.valueOf(status),code,message); }
    public HttpStatus status() { return status; }
    public String code() { return code; }
}
